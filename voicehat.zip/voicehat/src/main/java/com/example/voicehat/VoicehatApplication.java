package com.example.voicehat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoicehatApplication {

	public static void main(String[] args) {
		SpringApplication.run(VoicehatApplication.class, args);
	}

}
